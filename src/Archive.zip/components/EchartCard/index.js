import EchartCard from "./EchartCard.jsx";

export default EchartCard;
