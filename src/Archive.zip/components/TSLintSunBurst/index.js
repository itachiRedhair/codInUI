import TSLintSunBurst from "./TSLintSunBurst.jsx";

export default TSLintSunBurst;
