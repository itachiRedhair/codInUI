import TSLintSummary from "./TSLintSummary.jsx";

export default TSLintSummary;
