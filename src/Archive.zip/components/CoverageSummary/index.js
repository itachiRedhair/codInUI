import CoverageSummary from "./CoverageSummary.jsx";

export default CoverageSummary;
