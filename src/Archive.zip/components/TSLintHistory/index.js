import TSLintHistory from "./TSLintHistory.jsx";

export default TSLintHistory;
