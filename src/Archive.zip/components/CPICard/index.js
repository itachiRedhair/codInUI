import CPICard from "./CPICard.jsx";

export default CPICard;
