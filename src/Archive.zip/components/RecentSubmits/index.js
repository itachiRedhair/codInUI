import RecentSubmit from "./RecentSubmits.jsx";

export default RecentSubmit;
