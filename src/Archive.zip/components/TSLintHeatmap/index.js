import TSLintHeatmap from "./TSLintHeatmap.jsx";

export default TSLintHeatmap;
