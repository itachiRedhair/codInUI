import Content from "./Content.jsx";

export default Content;
