import DashboardComponent from "./DashboardComponent.jsx";

export default DashboardComponent;
