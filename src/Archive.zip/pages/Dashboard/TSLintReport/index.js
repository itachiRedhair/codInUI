import TSLintReport from "./TSLintReport.jsx";

export default TSLintReport;
