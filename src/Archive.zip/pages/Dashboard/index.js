import React, { Component } from "react";

//Component imports
import DashboardComponent from "./DashboardComponent";

export default class Dashboard extends Component {
  render() {
    return <DashboardComponent />;
  }
}
