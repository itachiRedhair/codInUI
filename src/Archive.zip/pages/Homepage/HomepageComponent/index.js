import { withRouter } from "react-router-dom";

import HomepageComponent from "./HomepageComponent.jsx";

export default withRouter(HomepageComponent);
