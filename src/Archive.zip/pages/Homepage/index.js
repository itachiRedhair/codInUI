import React, { Component } from "react";

//Component imports
import HomepageComponent from "./HomepageComponent";

export default class Homepage extends Component {
  render() {
    return (
      <div>
        <HomepageComponent />
      </div>
    );
  }
}
