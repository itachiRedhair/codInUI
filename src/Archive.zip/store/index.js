import configureStore from "./configureStore";

const initialState = {};

const store = configureStore(initialState);

export default store;
