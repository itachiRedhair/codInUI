import ModalComponent from "./ModalComponent.jsx";

export default ModalComponent;