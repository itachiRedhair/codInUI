import ButtonComponent from "./ButtonComponent.jsx";

export default ButtonComponent;
