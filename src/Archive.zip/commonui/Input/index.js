import InputComponent from "./InputComponent.jsx";

export default InputComponent;
