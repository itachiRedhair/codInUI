import Card from "./Card.jsx";

export default Card;
